package jess;

public enum EdgeEnum {
    HAS_TAG,
    PARENT_OF,
    POSTED
}
