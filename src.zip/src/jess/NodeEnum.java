package jess;

public enum NodeEnum {
        User,
        Tag,
        Post
}
