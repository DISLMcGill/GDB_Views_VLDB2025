package main;

//sorry for bad naming
public class SetTuple<X,Y>{

    public X x;
    public Y y;


    public SetTuple(X ex, Y wy){
        x = ex;
        y = wy;
    }

}