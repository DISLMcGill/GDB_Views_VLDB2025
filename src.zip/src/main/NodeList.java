package main;

import java.util.HashMap;
import java.util.HashSet;

public class NodeList {

    HashMap d = new HashMap();


}
